<?php
session_start();

// Hard-coded products data
function fetchProducts()
{
	return [
		[
			'name' => 'Classic White Shirt',
			'description' => 'A stylish and comfortable classic white shirt made from high-quality cotton. Perfect for casual and formal occasions.',
			'price' => '29.99',
			'image' => '../images/classic_white_shirt.jpeg' 
		],
		[
			'name' => 'Tech Notebook',
			'description' => 'A sleek and modern notebook ideal for tech enthusiasts. Features a durable cover and high-quality paper for all your notes.',
			'price' => '15.99',
			'image' => '../images/notebook.jpg' // Adjusted image path
		],
		[
			'name' => 'Wireless Mouse',
			'description' => 'Ergonomic wireless mouse with adjustable DPI settings and long battery life. Ideal for both office and gaming use.',
			'price' => '24.99',
			'image' => '../images/wireless_mouse.jpeg' // Adjusted image path
		],
		[
			'name' => 'Bluetooth Headphones',
			'description' => 'Premium Bluetooth headphones with noise-cancellation and high-fidelity sound. Enjoy music and calls with unparalleled clarity.',
			'price' => '79.99',
			'image' => '../images/bluetooth_headphones.jpg' // Adjusted image path
		]
	];
}

// Initialize shopping cart if not already initialized
if (!isset($_SESSION['cart'])) {
	$_SESSION['cart'] = [];
}

// Handle adding products to cart
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['product_name'])) {
	$product_name = $_POST['product_name'];
	if (!in_array($product_name, $_SESSION['cart'])) {
		$_SESSION['cart'][] = $product_name;
	}
}

// Handle removing products from cart
if (isset($_GET['remove'])) {
	$product_name = $_GET['remove'];
	if (($key = array_search($product_name, $_SESSION['cart'])) !== false) {
		unset($_SESSION['cart'][$key]);
	}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/styles.css">
	<title>My Products</title>
	<style>
		body {
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			background-color: #f5f5f5;
			margin: 0;
			padding: 0;
			color: #333;
		}

		.container {
			width: 80%;
			margin: 0 auto;
			background-color: #ffffff;
			padding: 20px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		}

		header {
			background-color: #84a9ac;
			color: #ffffff;
			padding: 20px 0;
			text-align: center;
		}

		header h1 {
			margin: 0;
			font-size: 2.5em;
			font-weight: 300;
		}

		nav {
			background-color: #3b6978;
			padding: 10px 0;
		}

		nav ul {
			list-style: none;
			padding: 0;
			margin: 0;
			text-align: center;
		}

		nav ul li {
			display: inline;
			margin: 0 10px;
		}

		nav ul li a {
			text-decoration: none;
			color: #ffffff;
			padding: 10px 20px;
			border-radius: 5px;
			transition: background-color 0.3s ease;
		}

		nav ul li a:hover {
			background-color: #204051;
		}

		.products-section {
			margin: 30px 0;
		}

		.products-section article {
			border: 1px solid #ddd;
			padding: 20px;
			margin-bottom: 20px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		}

		.products-section h2 {
			color: #333;
			font-size: 2em;
			margin-bottom: 10px;
		}

		.products-section p {
			font-size: 1.2em;
			color: #555;
			margin: 10px 0;
			line-height: 1.6em;

		}

		.products-section img {
			max-width: 100%;
			height: auto;
			border-radius: 5px;
		}

		.products-section form {
			margin-top: 10px;
		}

		.products-section button {
			background-color: #3b6978;
			color: #ffffff;
			border: none;
			padding: 10px 15px;
			border-radius: 5px;
			cursor: pointer;
			transition: background-color 0.3s ease;
		}

		.products-section button:hover {
			background-color: #204051;
		}

		.cart-section {
			margin-top: 30px;
		}

		.cart-section h2 {
			color: #333;
			font-size: 2em;
			margin-bottom: 10px;
		}

		.cart-section ul {
			list-style: none;
			padding: 0;
			margin: 0;
		}

		.cart-section li {
			font-size: 1.2em;
			color: #555;
			margin: 5px 0;
		}

		.cart-section a {
			color: #ff5722;
			text-decoration: none;
		}

		.cart-section a:hover {
			text-decoration: underline;
		}

		footer {
			text-align: center;
			padding: 10px 0;
			background-color: #84a9ac;
			color: #ffffff;
		}
	</style>
</head>

<body>
	<header>
		<h1>My Products</h1>
		<p>Product listings with add/remove functionality.</p>
		<nav>
			<ul>
				<li><a href="../index.php">Home</a></li>
				<li><a href="../resume/resume.php">Resume</a></li>
				<li><a href="../past_projects/past_projects.php">Past Projects</a></li>
				<li><a href="products.php">My Products</a></li>
				<li><a href="../fan/fan.php">Become a Fan</a></li>
				<li><a href="../news/news.php">News</a></li>
				<li><a href="../admin/admin.php">Admin</a></li>
			</ul>
		</nav>
	</header>
	<div class="container">
		<section class="products-section">
			<?php
			$products = fetchProducts();

			if (empty($products)) {
				echo "<p>No products found.</p>";
			} else {
				foreach ($products as $product) {
					echo "<article>";
					echo "<h2>{$product['name']}</h2>";
					echo "<p>{$product['description']}</p>";
					echo "<p>Price: \${$product['price']}</p>";
					if (!empty($product['image'])) {
						echo "<img src='{$product['image']}' alt='Product Image'>";
					}
					echo "<form method='post' action='products.php'>";
					echo "<input type='hidden' name='product_name' value='{$product['name']}'>";
					echo "<button type='submit'>Add to Cart</button>";
					echo "</form>";
					echo "</article>";
				}
			}
			?>
		</section>
		<section class="cart-section">
			<h2>Shopping Cart</h2>
			<ul>
				<?php
				if (empty($_SESSION['cart'])) {
					echo "<p>Your cart is empty.</p>";
				} else {
					foreach ($_SESSION['cart'] as $cart_item) {
						echo "<li>$cart_item <a href='products.php?remove=$cart_item'>Remove</a></li>";
					}
				}
				?>
			</ul>
		</section>
	</div>
	<footer>
		<p>&copy; 2024 Manas Kalra. All Rights Reserved.</p>
	</footer>
</body>

</html>
