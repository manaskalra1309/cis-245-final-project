<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Become a Fan</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
        }

        header {
            background-color: #84a9ac;
            color: #ffffff;
            padding: 20px 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2.5em;
            font-weight: 300;
        }

        nav {
            background-color: #3b6978;
            padding: 10px 0;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #204051;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-section {
            margin: 30px 0;
        }

        .form-section h2 {
            color: #333;
            font-size: 2em;
            margin-bottom: 10px;
        }

        .form-section form {
            background-color: #ffffff;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-section label {
            display: block;
            margin-bottom: 10px;
            font-size: 1.1em;
            color: #555;
        }

        .form-section input[type="text"],
        .form-section input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
        }

        .form-section button {
            background-color: #3b6978;
            color: #ffffff;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
        }

        .form-section button:hover {
            background-color: #204051;
        }

        footer {
            text-align: center;
            padding: 10px 0;
            background-color: #84a9ac;
            color: #ffffff;
        }
    </style>
</head>

<body>
    <header>
        <h1>Become a Fan</h1>
        <p>Registration and login form.</p>
        <nav>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../resume/resume.php">Resume</a></li>
                <li><a href="../past_projects/past_projects.php">Past Projects</a></li>
                <li><a href="../products/products.php">My Products</a></li>
                <li><a href="../fan/fan.php">Become a Fan</a></li>
                <li><a href="../news/news.php">News</a></li>
                <li><a href="../admin/admin.php">Admin</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <section class="form-section">
            <h2>Register</h2>
            <form action="register.php" method="post">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <button type="submit">Register</button>
            </form>
        </section>
        <section class="form-section">
            <h2>Login</h2>
            <form action="login.php" method="post">
                <label for="loginUsername">Username:</label>
                <input type="text" id="loginUsername" name="loginUsername" required>
                <label for="loginPassword">Password:</label>
                <input type="password" id="loginPassword" name="loginPassword" required>
                <button type="submit">Login</button>
            </form>
        </section>
    </div>
    <footer>
        <p>&copy; 2024 Manas Kalra. All Rights Reserved.</p>
    </footer>
</body>

</html>