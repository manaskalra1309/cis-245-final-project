<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Past Projects</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        header {
            background-color: #84a9ac;
            color: #ffffff;
            padding: 20px 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2.5em;
            font-weight: 300;
        }

        nav {
            background-color: #3b6978;
            padding: 10px 0;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #204051;
        }

        .projects-section {
            margin: 20px 0;
        }

        .projects-section article {
            background-color: #e6e6e6;
            padding: 20px;
            border-radius: 10px;
            margin: 10px 0;
        }

        .projects-section article h2 {
            margin: 0;
            font-size: 1.5em;
            color: #333;
        }

        .projects-section article p {
            margin: 10px 0;
            font-size: 1em;
            color: #555;
        }

        .footer {
            text-align: center;
            padding: 10px 0;
            background-color: #84a9ac;
            color: #ffffff;
        }
    </style>
</head>

<body>
    <header>
        <h1>Past Projects</h1>
        <nav>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../resume/resume.php">Resume</a></li>
                <li><a href="past_projects.php">Past Projects</a></li>
                <li><a href="../products/products.php">My Products</a></li>
                <li><a href="../fan/fan.php">Become a Fan</a></li>
                <li><a href="../news/news.php">News</a></li>
                <li><a href="../admin/admin.php">Admin</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <section class="projects-section">
            <?php
            $projects = [
                [
                    "title" => "Automobile Gas Mileage Simulation",
                    "description" => "Created a Python program to estimate vehicle mileage, incorporating if-else statements, loops, arrays, and user inputs for precise and reliable results. Designed and implemented a comprehensive functionality to calculate expenses at various gas stations, showcasing problem-solving skills, meticulous attention to detail, and a focus on optimizing cost efficiency.",
                    "link" => ""
                ],
                [
                    "title" => "Web-Based Inventory Management System",
                    "description" => "Developed a web-based inventory management system using PHP, MySQL, and JavaScript. The system allows users to track inventory levels, manage stock, and generate reports. Implemented user authentication and role-based access control to ensure data security.",
                    "link" => ""
                ],
                [
                    "title" => "Machine Learning Model for Predictive Analytics",
                    "description" => "Built a machine learning model using Python and scikit-learn to predict customer churn for a telecommunications company. The model analyzes customer data to identify patterns and provides insights to improve customer retention strategies.",
                    "link" => ""
                ],
                [
                    "title" => "Mobile App for Health Tracking",
                    "description" => "Developed a mobile application using React Native for tracking health and fitness activities. The app includes features such as activity logging, goal setting, and progress tracking. Integrated with APIs to fetch health data from wearable devices.",
                    "link" => ""
                ],
                [
                    "title" => "Cybersecurity Awareness Campaign",
                    "description" => "Organized a cybersecurity awareness campaign for students at the University of the Fraser Valley. Created educational materials and conducted workshops on topics such as phishing, password security, and safe browsing practices.",
                    "link" => ""
                ]
            ];

            foreach ($projects as $project) {
                echo "<article>";
                echo "<h2>{$project['title']}</h2>";
                echo "<p>{$project['description']}</p>";
                if ($project['link']) {
                    echo "<p><a href='{$project['link']}' target='_blank'>Project Link</a></p>";
                }
                echo "</article>";
            }
            ?>
        </section>
    </div>
    <footer class="footer">
        <p>&copy; 2024 Manas Kalra. All Rights Reserved.</p>
    </footer>
</body>

</html>