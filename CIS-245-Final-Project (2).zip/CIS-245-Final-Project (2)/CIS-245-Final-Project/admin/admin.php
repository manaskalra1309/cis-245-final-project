<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Admin</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
        }

        header {
            background-color: #84a9ac;
            color: #ffffff;
            padding: 20px 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2.5em;
            font-weight: 300;
        }

        nav {
            background-color: #3b6978;
            padding: 10px 0;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #204051;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-section {
            margin: 30px 0;
        }

        .form-section h2 {
            color: #333;
            font-size: 2em;
            margin-bottom: 10px;
        }

        .form-section form {
            background-color: #ffffff;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-section label {
            display: block;
            margin-bottom: 10px;
            font-size: 1.1em;
            color: #555;
        }

        .form-section input[type="text"],
        .form-section input[type="number"],
        .form-section input[type="file"],
        .form-section textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
        }

        .form-section button {
            background-color: #3b6978;
            color: #ffffff;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
        }

        .form-section button:hover {
            background-color: #204051;
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <h1>Admin Page</h1>
            <p>Upload pictures or texts to the News page and add new products to the My Products page.</p>
        </header>
        <nav>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="../resume/resume.php">Resume</a></li>
                <li><a href="../past_projects/past_projects.php">Past Projects</a></li>
                <li><a href="../products/products.php">My Products</a></li>
                <li><a href="../fan/fan.php">Become a Fan</a></li>
                <li><a href="../news/news.php">News</a></li>
                <li><a href="admin.php">Admin</a></li>
            </ul>
        </nav>
        <section class="form-section">
            <h2>Upload to News Page</h2>
            <form action="upload_news.php" method="post" enctype="multipart/form-data">
                <label for="newsTitle">Title:</label>
                <input type="text" id="newsTitle" name="newsTitle" required>
                <label for="newsContent">Content:</label>
                <textarea id="newsContent" name="newsContent" required></textarea>
                <label for="newsImage">Upload Image:</label>
                <input type="file" id="newsImage" name="newsImage" accept="image/*">
                <button type="submit">Upload</button>
            </form>
        </section>
        <section class="form-section">
            <h2>Add New Product</h2>
            <form action="add_product.php" method="post" enctype="multipart/form-data">
                <label for="productName">Product Name:</label>
                <input type="text" id="productName" name="productName" required>
                <label for="productDescription">Description:</label>
                <textarea id="productDescription" name="productDescription" required></textarea>
                <label for="productPrice">Price:</label>
                <input type="number" id="productPrice" name="productPrice" step="0.01" required>
                <label for="productImage">Upload Image:</label>
                <input type="file" id="productImage" name="productImage" accept="image/*">
                <button type="submit">Add Product</button>
            </form>
        </section>
    </div>
</body>

</html>