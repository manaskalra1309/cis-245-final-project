<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$name = $_POST['productName'];
	$description = $_POST['productDescription'];
	$price = $_POST['productPrice'];
	$image = $_FILES['productImage'];

	// Directory where product images will be saved
	$targetDir = "../images/products/";
	$targetFile = $targetDir . basename($image['name']);
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

	// Check if image file is a actual image or fake image
	if (isset($_POST["submit"])) {
		$check = getimagesize($image["tmp_name"]);
		if ($check !== false) {
			$uploadOk = 1;
		} else {
			echo "File is not an image.";
			$uploadOk = 0;
		}
	}

	// Check if file already exists
	if (file_exists($targetFile)) {
		echo "Sorry, file already exists.";
		$uploadOk = 0;
	}

	// Check file size
	if ($image["size"] > 500000) {
		echo "Sorry, your file is too large.";
		$uploadOk = 0;
	}

	// Allow certain file formats
	if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
	&& $imageFileType != "gif") {
		echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
		$uploadOk = 0;
	}

	// Check if $uploadOk is set to 0 by an error
	if ($uploadOk == 0) {
		echo "Sorry, your file was not uploaded.";
	// if everything is ok, try to upload file
	} else {
		if (move_uploaded_file($image["tmp_name"], $targetFile)) {
			// Save product content to a file or database here
			// Example: save to a text file
			$productFile = "../products/products.txt";
			$currentContent = file_get_contents($productFile);
			$newContent = "Name: $name\nDescription: $description\nPrice: $price\nImage: $targetFile\n\n" . $currentContent;
			file_put_contents($productFile, $newContent);

			echo "The file ". htmlspecialchars(basename($image["name"])). " has been uploaded.";
		} else {
			echo "Sorry, there was an error uploading your file.";
		}
	}
}
?>
