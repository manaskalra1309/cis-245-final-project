<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Resume</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            background-color: #e6eee6;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        header {
            background-color: #84a9ac;
            color: #ffffff;
            padding: 20px 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2.5em;
            font-weight: 300;
        }

        nav {
            background-color: #3b6978;
            padding: 10px 0;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #204051;
        }

        .resume-section {
            margin: 30px 0;
        }

        .resume-section h2 {
            color: #333;
            font-size: 2em;
            margin-bottom: 10px;
        }

        .resume-section p {
            font-size: 1.2em;
            color: #555;
            margin: 10px 0;
            line-height: 1.6em;
        }

        footer {
            text-align: center;
            padding: 10px 0;
            background-color: #84a9ac;
            color: #ffffff;
        }
    </style>
</head>

<body>
    <header>
        <h1>Resume</h1>
        <p>Education background and job experience.</p>
        <nav>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="resume.php">Resume</a></li>
                <li><a href="../past_projects/past_projects.php">Past Projects</a></li>
                <li><a href="../products/products.php">My Products</a></li>
                <li><a href="../fan/fan.php">Become a Fan</a></li>
                <li><a href="../news/news.php">News</a></li>
                <li><a href="../admin/admin.php">Admin</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <section class="resume-section">
            <h2>Education</h2>
            <?php
            $resumeFile = "../resume/education.txt";
            if (file_exists($resumeFile)) {
                $educationContent = file_get_contents($resumeFile);
                $educationItems = explode("\n\n", trim($educationContent));
                foreach ($educationItems as $item) {
                    echo "<p>$item</p>";
                }
            } else {
                echo "<p><strong>CIS Diploma:</strong> University of the Fraser Valley (UFV)</p>
                          <p><strong>Expected Graduation:</strong> 2025</p>
                          <p><strong>Secondary Education:</strong> St. Joseph's School, India</p>
                          <p><strong>Graduated:</strong> 2021</p>";
            }
            ?>
            <h2>Job Experience</h2>
            <?php
            $jobFile = "../resume/jobs.txt";
            if (file_exists($jobFile)) {
                $jobContent = file_get_contents($jobFile);
                $jobItems = explode("\n\n", trim($jobContent));
                foreach ($jobItems as $item) {
                    echo "<p>$item</p>";
                }
            } else {
                echo "<p><strong>Bartender</strong></p>
                          <p><strong>[Cactus Club Cafe]</strong></p>
                          <p>Prepared and served beverages to customers, ensuring adherence to recipes and quality standards.</p>
                          <p>Engaged with customers to create a welcoming atmosphere and promote repeat business.</p>
                          <p>Managed cash transactions and maintained accurate records of sales.</p>
                          <p><strong>IT Support Specialist</strong></p>
                          <p><strong>[Tech Solutions Inc.]</strong></p>
                          <p>Provided technical support for hardware and software issues, resolving issues promptly to minimize downtime.</p>
                          <p>Assisted with the setup and maintenance of IT systems, including network configuration and troubleshooting.</p>
                          <p>Documented technical procedures and created user guides to improve internal processes.</p>
                          <p><strong>Software Developer Intern</strong></p>
                          <p><strong>[Innovate Technologies]</strong></p>
                          <p>Collaborated on developing web applications using JavaScript, HTML, and CSS, enhancing user interface and experience.</p>
                          <p>Participated in code reviews and testing to ensure high-quality deliverables.</p>
                          <p>Contributed to debugging and optimizing existing codebases to improve performance.</p>
                          <p><strong>Customer Service Representative</strong></p>
                          <p><strong>[Service Experts]</strong></p>
                          <p>Managed customer inquiries and complaints, providing timely solutions and support.</p>
                          <p>Processed orders and handled returns, ensuring customer satisfaction and retention.</p>
                          <p>Maintained up-to-date knowledge of product offerings and company policies.</p>";
            }
            ?>
            <h2>Volunteering Experience</h2>
            <p><strong>Volunteer IT Support</strong></p>
            <p><strong>[Local Community Center]</strong></p>
            <p>Assisted with setting up and maintaining computer systems for community events and workshops.</p>
            <p>Provided training to users on basic computer skills and software applications.</p>
            <p>Helped organize and execute technology-related community outreach programs.</p>

            <p><strong>Tech Workshop Facilitator</strong></p>
            <p><strong>[Youth Technology Initiative]</strong></p>
            <p>Led workshops on coding and digital literacy for students and young adults.</p>
            <p>Developed educational materials and resources to enhance learning experiences.</p>
            <p>Mentored participants in hands-on projects and provided guidance on technology careers.</p>

            <h2>Certifications</h2>
            <p><strong>Certified Information Systems Security Professional (CISSP)</strong></p>
            <p><strong>CompTIA A+</strong></p>
            <p><strong>Microsoft Certified: Azure Fundamentals</strong></p>
            <p><strong>Certified Ethical Hacker (CEH)</strong></p>
        </section>
    </div>
    <footer>
        <p>&copy; 2024 Manas Kalra. All Rights Reserved.</p>
    </footer>
</body>

</html>