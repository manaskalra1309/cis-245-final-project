<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Profile</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        header {
            background-color: #84a9ac;
            color: #ffffff;
            padding: 20px 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2.5em;
            font-weight: 300;
        }

        .profile-picture {
            width: 300px;
            height: 300px;
            border-radius: 50%;
            margin-top: 20px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

        .profile-info {
            list-style: none;
            padding: 0;
            text-align: center;
            margin: 20px 0;
        }

        .profile-info li {
            font-size: 18px;
            color: #555;
            margin: 5px 0;
        }

        .profile-info li ul {
            margin: 10px 0 0 20px;
            text-align: left;
        }

        nav {
            background-color: #3b6978;
            padding: 10px 0;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: center;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            text-decoration: none;
            color: #ffffff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: #204051;
        }

        .about {
            background-color: #dbe2ef;
            padding: 20px;
            margin: 20px 0;
            border-radius: 10px;
        }

        .skills {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }

        .skill {
            background-color: #e6e6e6;
            padding: 20px;
            border-radius: 10px;
            width: 30%;
            text-align: center;
        }

        .contact {
            background-color: #dbe2ef;
            padding: 20px;
            margin: 20px 0;
            border-radius: 10px;
            text-align: center;
        }

        .footer {
            text-align: center;
            padding: 10px 0;
            background-color: #84a9ac;
            color: #ffffff;
        }

        .container {
            background-color: #e6eee6;
            padding: 20px;
            border-radius: 10px;
            width: 70%;
            text-align: center;
        }

    </style>
</head>

<body>
    <header>
        <h1>Welcome to My Personal Profile Website</h1>
        <nav>
            <ul>
                <li><a href="resume/resume.php">Resume</a></li>
                <li><a href="past_projects/past_projects.php">Past Projects</a></li>
                <li><a href="products/products.php">My Products</a></li>
                <li><a href="fan/fan.php">Become a Fan</a></li>
                <li><a href="news/news.php">News</a></li>
                <li><a href="admin/admin.php">Admin</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <img src="images/profile.jpg" alt="Profile Picture of Manas Kalra" class="profile-picture">
        <ul class="profile-info">
            <li>Manas Kalra</li>
            <li>Student ID: 300201243</li>
            <li>Program: CIS Diploma</li>
            <li>Institution: University of the Fraser Valley (UFV)</li>
        </ul>
        <section class="about">
            <h2>About Me</h2>
            <p>Hello! I'm Manas, a tech enthusiast with a passion for learning and exploring new technologies. I am
                currently pursuing a CIS Diploma at UFV, where I am honing my skills in various programming languages
                and technologies.</p>
                <p>Enthusiastic and dedicated international student with a strong foundation in computer information
                systems, currently pursuing a diploma at UFV. Experienced in customer service through part-time roles,
                demonstrating excellent interpersonal and communication skills. Adept at managing multiple tasks and
                thriving in fast-paced environments.</p>
                <li>Languages:
                <ul>
                    <li>English (Fluent)</li>
                    <li>Hindi (Fluent)</li>
                </ul>
            </li>
        </section>
        <section class="skills">
            <div class="skill">
                <h3>Programming Languages</h3>
                <p>Java, Python, C++</p>
            </div>
            <div class="skill">
                <h3>Web Technologies</h3>
                <p>HTML, CSS, JavaScript</p>
            </div>
            <div class="skill">
                <h3>Database Management</h3>
                <p>MySQL, MongoDB</p>
            </div>
        </section>
        <section class="contact">
            <h2>Contact Me</h2>
            <p>Email: manas.kalra@student.ufv.ca</p>
            <p>Phone: 778-758-3313</p>
        </section>
    </div>
    <footer class="footer">
        <p>&copy; 2024 Manas Kalra. All Rights Reserved.</p>
    </footer>
</body>

</html>